#if defined(ESP8266) || defined(ESP32)
#include "arduino/wifi.hpp"
painlessmesh::logger::LogClass Log;
#endif